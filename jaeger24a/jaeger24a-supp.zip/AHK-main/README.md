source code for A Simple Latent Variable Model for Graph Learning and Inference

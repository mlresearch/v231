MODULE_CONFIG = {
    'tsp': {
        'node_features': 1,
        'edge_features': 1,
        'output_features': 1,
    },
    'mst_prim': {
        'node_features': 1,
        'edge_features': 1,
        'output_features': 1,
    },
}

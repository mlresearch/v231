## Introduction

This is the code repository for the experiments. This implementation is modified based on Chamberlain et al.[1]'s current implementation.

## Running experiments

### Requirements
Dependencies (with python >= 3.9):
Main dependencies are

pytorch==1.13

torch_geometric==2.2.0

torch-scatter==2.1.1+pt113cpu

torch-sparse==0.6.17+pt113cpu

torch-spline-conv==1.2.2+pt113cpu

### Experiments
To run experiments

```
python run.py --dataset <dataset name>
```

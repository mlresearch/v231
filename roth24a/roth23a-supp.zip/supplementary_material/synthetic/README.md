# Repository

This repository contains the implementation for "Rank Collapse Causes Over-Smoothing and Over-Correlation in Graph Neural Networks".
## Dependencies

This code requires the following dependencies to be installed:

* Python > 3
* PyTorch > 2.0
* PyTorch Geometric >= 2.3

## Usage

To run the experiment that compares the Dirichlet energy and the norm, simply execute "norm_vs_dirichlet_energy.py". Figures will be directly generated.

To run the experiment comparing the performance of GAT, FAGCN, and SKP on random graphs, run "er_main.py" with the following arguments:

* --conv={gat,fagcn,skp} Choose the desired model.
* -ho Set this when the aggregation matrices for all layers should be homogeneous.
* -li Set this when no activation function should be applied
* --num_graphs Number of graphs to repeat the experiment for
* --start_graph Starting seed of the initial graph
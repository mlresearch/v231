# Repository

This repository contains the implementation for "Rank Collapse Causes Over-Smoothing and Over-Correlation in Graph Neural Networks".
## Dependencies

This code requires the following dependencies to be installed:

* Python > 3
* PyTorch > 2.0
* PyTorch Geometric >= 2.3

## Usage

To run the experiments, simply execute "main.py" with the following arguments:

* --convs={KP,softmax_SKP,SKP} Choose the desired models.
* --datasets={Cora, Citeseer, Pubmed,texas,cornell,wisconsin,film,chameleon,squirrel} Choose the desired datasets.
* --h_dim Hidden dimension of the model
* --layers Number of layers